Doodle jump en javascript-------------------------
Url     : http://codes-sources.commentcamarche.net/source/53249-doodle-jump-en-javascriptAuteur  : Toshy62Date    : 14/08/2013
Licence :
=========

Ce document intitul� � Doodle jump en javascript � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Voil&agrave; une version du c&eacute;l&egrave;bre jeu pour iphone Doodle Jump co
d&eacute; en Javascript avec l'&eacute;l&eacute;ment canvas. La version ne conti
ent pas de monstre ni de bonus mais est une base pour toute modification ult&eac
ute;rieur.
<br />
<br />Le code est sous licence BSD
<br /><a name='source-ex
emple'></a><h2> Source / Exemple : </h2>
<br /><pre class='code' data-mode='ba
sic'>
Tout est dans le zip
</pre>
